package com.combatlog.plugin;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.ShulkerBox;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.Map;

public class ItemRegistry {

    private static final String TAG = "cl_t";
    private final NamespacedKey nk;

    public ItemRegistry(Plugin p) {
        this.nk = new NamespacedKey(p, TAG);
    }

    // Returns a plain black carpet with a hidden tag — no name, no lore
    public ItemStack buildToken() {
        final ItemStack i = new ItemStack(Material.BLACK_CARPET);
        final ItemMeta m = i.getItemMeta();
        m.getPersistentDataContainer().set(nk, PersistentDataType.BYTE, (byte) 1);
        m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS,
                       ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        i.setItemMeta(m);
        return i;
    }

    public boolean isToken(ItemStack i) {
        if (i == null || i.getType() != Material.BLACK_CARPET || !i.hasItemMeta()) return false;
        return i.getItemMeta().getPersistentDataContainer().has(nk, PersistentDataType.BYTE);
    }

    // Builds the reward — plain black shulker, no custom name or lore
    public ItemStack buildReward() {
        final ItemStack si = new ItemStack(Material.BLACK_SHULKER_BOX);
        final BlockStateMeta bsm = (BlockStateMeta) si.getItemMeta();
        final ShulkerBox box = (ShulkerBox) bsm.getBlockState();
        final Inventory inv = box.getInventory();

        inv.setItem(0,  arm(Material.DIAMOND_HELMET));
        inv.setItem(1,  arm(Material.DIAMOND_CHESTPLATE));
        inv.setItem(2,  arm(Material.DIAMOND_LEGGINGS));
        inv.setItem(3,  arm(Material.DIAMOND_BOOTS));
        inv.setItem(4,  weap(Material.DIAMOND_SWORD));
        inv.setItem(5,  tool(Material.DIAMOND_PICKAXE));
        inv.setItem(6,  tool(Material.DIAMOND_AXE));
        inv.setItem(7,  ranged(Material.BOW));
        inv.setItem(8,  ranged(Material.CROSSBOW));
        inv.setItem(9,  shield());
        inv.setItem(10, new ItemStack(Material.TOTEM_OF_UNDYING,       2));
        inv.setItem(11, new ItemStack(Material.GOLDEN_APPLE,           16));
        inv.setItem(12, new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 4));
        inv.setItem(13, new ItemStack(Material.ARROW,                  64));
        inv.setItem(14, new ItemStack(Material.ENDER_PEARL,            16));

        bsm.setBlockState(box);
        bsm.addItemFlags(ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        si.setItemMeta(bsm);
        return si;
    }

    // ── private builders ─────────────────────────────────────────────────────

    private ItemStack arm(Material t) {
        final ItemStack i = new ItemStack(t);
        switch (t) {
            case DIAMOND_HELMET -> enc(i, Map.of(
                Enchantment.PROTECTION,    4,
                Enchantment.UNBREAKING,    3,
                Enchantment.RESPIRATION,   3,
                Enchantment.AQUA_AFFINITY, 1,
                Enchantment.MENDING,       1
            ));
            case DIAMOND_CHESTPLATE -> enc(i, Map.of(
                Enchantment.PROTECTION, 4,
                Enchantment.UNBREAKING, 3,
                Enchantment.MENDING,    1
            ));
            case DIAMOND_LEGGINGS -> enc(i, Map.of(
                Enchantment.PROTECTION,  4,
                Enchantment.UNBREAKING,  3,
                Enchantment.SWIFT_SNEAK, 3,
                Enchantment.MENDING,     1
            ));
            case DIAMOND_BOOTS -> enc(i, Map.of(
                Enchantment.PROTECTION,      4,
                Enchantment.UNBREAKING,      3,
                Enchantment.FEATHER_FALLING, 4,
                Enchantment.DEPTH_STRIDER,   3,
                Enchantment.SOUL_SPEED,      3,
                Enchantment.MENDING,         1
            ));
            default -> {}
        }
        return i;
    }

    private ItemStack weap(Material t) {
        final ItemStack i = new ItemStack(t);
        enc(i, Map.of(
            Enchantment.SHARPNESS,     5,
            Enchantment.UNBREAKING,    3,
            Enchantment.LOOTING,       3,
            Enchantment.FIRE_ASPECT,   2,
            Enchantment.SWEEPING_EDGE, 3,
            Enchantment.KNOCKBACK,     2,
            Enchantment.MENDING,       1
        ));
        return i;
    }

    private ItemStack tool(Material t) {
        final ItemStack i = new ItemStack(t);
        enc(i, Map.of(
            Enchantment.EFFICIENCY, 5,
            Enchantment.FORTUNE,    3,
            Enchantment.UNBREAKING, 3,
            Enchantment.MENDING,    1
        ));
        return i;
    }

    private ItemStack ranged(Material t) {
        final ItemStack i = new ItemStack(t);
        if (t == Material.BOW) {
            enc(i, Map.of(
                Enchantment.POWER,      5,
                Enchantment.PUNCH,      2,
                Enchantment.FLAME,      1,
                Enchantment.INFINITY,   1,
                Enchantment.UNBREAKING, 3,
                Enchantment.MENDING,    1
            ));
        } else {
            enc(i, Map.of(
                Enchantment.QUICK_CHARGE, 3,
                Enchantment.MULTISHOT,    1,
                Enchantment.PIERCING,     4,
                Enchantment.UNBREAKING,   3,
                Enchantment.MENDING,      1
            ));
        }
        return i;
    }

    private ItemStack shield() {
        final ItemStack i = new ItemStack(Material.SHIELD);
        enc(i, Map.of(Enchantment.UNBREAKING, 3, Enchantment.MENDING, 1));
        return i;
    }

    private void enc(ItemStack i, Map<Enchantment, Integer> e) {
        e.forEach(i::addUnsafeEnchantment);
    }
}
