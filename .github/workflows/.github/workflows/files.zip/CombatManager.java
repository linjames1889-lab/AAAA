package com.combatlog.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CombatManager {

    private final CombatLogPlugin plugin;
    private final Map<UUID, BukkitTask> combatTasks = new HashMap<>();
    private final Map<UUID, Integer> combatCountdowns = new HashMap<>();

    private final int combatDuration;

    public CombatManager(CombatLogPlugin plugin) {
        this.plugin = plugin;
        this.combatDuration = plugin.getConfig().getInt("combat-duration", 30);
    }

    /** Tags a player as in combat, resetting the timer if already tagged. */
    public void tag(Player player) {
        final UUID uuid = player.getUniqueId();
        final boolean alreadyTagged = combatTasks.containsKey(uuid);

        // Cancel existing countdown
        if (alreadyTagged) {
            combatTasks.get(uuid).cancel();
        }

        combatCountdowns.put(uuid, combatDuration);

        if (!alreadyTagged) {
            player.sendMessage(Component.text("⚔ You are now in combat! ", NamedTextColor.RED)
                    .append(Component.text(combatDuration + "s remaining.", NamedTextColor.YELLOW)));
        } else {
            player.sendMessage(Component.text("⚔ Combat timer reset! ", NamedTextColor.RED)
                    .append(Component.text(combatDuration + "s remaining.", NamedTextColor.YELLOW)));
        }

        // Tick every second
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            final Player p = Bukkit.getPlayer(uuid);
            final int timeLeft = combatCountdowns.getOrDefault(uuid, 0) - 1;

            if (timeLeft <= 0 || p == null) {
                removeCombatTag(uuid);
                if (p != null) {
                    p.sendMessage(Component.text("✔ You are no longer in combat.", NamedTextColor.GREEN));
                }
                return;
            }

            combatCountdowns.put(uuid, timeLeft);

            if (timeLeft <= 5 || timeLeft == 10) {
                p.sendMessage(Component.text("⚔ Combat ends in ", NamedTextColor.YELLOW)
                        .append(Component.text(timeLeft + "s", NamedTextColor.RED, TextDecoration.BOLD))
                        .append(Component.text(".", NamedTextColor.YELLOW)));
            }
        }, 20L, 20L);

        combatTasks.put(uuid, task);
    }

    public boolean isInCombat(UUID uuid) {
        return combatTasks.containsKey(uuid);
    }

    public boolean isInCombat(Player player) {
        return isInCombat(player.getUniqueId());
    }

    public int getTimeLeft(UUID uuid) {
        return combatCountdowns.getOrDefault(uuid, 0);
    }

    /** Admin force-remove. */
    public void forceRemove(UUID uuid) {
        removeCombatTag(uuid);
    }

    private void removeCombatTag(UUID uuid) {
        final BukkitTask task = combatTasks.remove(uuid);
        if (task != null) task.cancel();
        combatCountdowns.remove(uuid);
    }

    /**
     * Punish a player who disconnected during combat:
     * drops all items at their location and kills them.
     */
    public void punishCombatLogger(Player player) {
        if (!isInCombat(player.getUniqueId())) return;

        // Drop inventory contents
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && !item.getType().isAir()) {
                player.getWorld().dropItemNaturally(player.getLocation(), item);
            }
        }
        // Drop armour
        for (ItemStack item : player.getInventory().getArmorContents()) {
            if (item != null && !item.getType().isAir()) {
                player.getWorld().dropItemNaturally(player.getLocation(), item);
            }
        }
        // Drop offhand
        final ItemStack offhand = player.getInventory().getItemInOffHand();
        if (!offhand.getType().isAir()) {
            player.getWorld().dropItemNaturally(player.getLocation(), offhand);
        }

        player.getInventory().clear();

        // Kill the player
        player.setHealth(0.0);

        Bukkit.broadcast(
            Component.text("☠ ", NamedTextColor.RED)
                .append(Component.text(player.getName(), NamedTextColor.YELLOW))
                .append(Component.text(" logged out during combat and died!", NamedTextColor.RED))
        );

        removeCombatTag(player.getUniqueId());
    }

    public void clearAll() {
        combatTasks.values().forEach(BukkitTask::cancel);
        combatTasks.clear();
        combatCountdowns.clear();
    }

    public int getCombatDuration() {
        return combatDuration;
    }
}
