package com.combatlog.plugin;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class CombatLogPlugin extends JavaPlugin {

    private CombatManager combatManager;
    private ItemRegistry itemRegistry;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        combatManager = new CombatManager(this);
        getServer().getPluginManager().registerEvents(new CombatListener(this, combatManager), this);

        itemRegistry = new ItemRegistry(this);
        registerRecipes();
        getServer().getPluginManager().registerEvents(new InteractHandler(itemRegistry), this);

        final var cmd = getCommand("combatlog");
        if (cmd != null) {
            final var executor = new CombatCommand(combatManager);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }

        getLogger().info("CombatLog enabled.");
    }

    @Override
    public void onDisable() {
        if (combatManager != null) combatManager.clearAll();
    }

    private void registerRecipes() {
        final NamespacedKey key = new NamespacedKey(this, "cl_r1");
        final ShapedRecipe recipe = new ShapedRecipe(key, itemRegistry.buildToken());
        recipe.shape("AA", "AA");
        recipe.setIngredient('A', Material.BLACK_CARPET);
        getServer().addRecipe(recipe);
    }

    public CombatManager getCombatManager() { return combatManager; }
    public ItemRegistry getItemRegistry()   { return itemRegistry; }
}
