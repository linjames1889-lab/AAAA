package com.combatlog.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;

public class CombatCommand implements CommandExecutor, TabCompleter {

    private final CombatManager combatManager;

    public CombatCommand(CombatManager combatManager) {
        this.combatManager = combatManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(Component.text("=== CombatLog ===", NamedTextColor.GOLD));
            sender.sendMessage(Component.text("/combatlog status [player]", NamedTextColor.YELLOW)
                    .append(Component.text(" — Check combat status", NamedTextColor.WHITE)));
            sender.sendMessage(Component.text("/combatlog untag <player>", NamedTextColor.YELLOW)
                    .append(Component.text(" — Remove a player's combat tag (admin)", NamedTextColor.WHITE)));
            return true;
        }

        return switch (args[0].toLowerCase()) {
            case "status" -> handleStatus(sender, args);
            case "untag"  -> handleUntag(sender, args);
            default -> {
                sender.sendMessage(Component.text("Unknown subcommand. Use /combatlog help.", NamedTextColor.RED));
                yield true;
            }
        };
    }

    private boolean handleStatus(CommandSender sender, String[] args) {
        final Player target;

        if (args.length < 2) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage(Component.text("Specify a player name.", NamedTextColor.RED));
                return true;
            }
            target = p;
        } else {
            target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED));
                return true;
            }
        }

        if (combatManager.isInCombat(target)) {
            sender.sendMessage(
                Component.text("⚔ " + target.getName() + " is in combat — ", NamedTextColor.RED)
                    .append(Component.text(combatManager.getTimeLeft(target.getUniqueId()) + "s remaining.", NamedTextColor.YELLOW))
            );
        } else {
            sender.sendMessage(Component.text("✔ " + target.getName() + " is not in combat.", NamedTextColor.GREEN));
        }
        return true;
    }

    private boolean handleUntag(CommandSender sender, String[] args) {
        if (!sender.hasPermission("combatlog.admin")) {
            sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(Component.text("Usage: /combatlog untag <player>", NamedTextColor.RED));
            return true;
        }
        final Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED));
            return true;
        }
        if (!combatManager.isInCombat(target)) {
            sender.sendMessage(Component.text(target.getName() + " is not in combat.", NamedTextColor.YELLOW));
            return true;
        }
        combatManager.forceRemove(target.getUniqueId());
        target.sendMessage(Component.text("✔ Your combat tag was removed by an admin.", NamedTextColor.GREEN));
        sender.sendMessage(Component.text("Removed combat tag from " + target.getName() + ".", NamedTextColor.GREEN));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("status", "untag", "help").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .toList();
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("status") || args[0].equalsIgnoreCase("untag"))) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .toList();
        }
        return List.of();
    }
}
