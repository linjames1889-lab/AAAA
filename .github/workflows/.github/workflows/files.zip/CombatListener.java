package com.combatlog.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Set;

public class CombatListener implements Listener {

    private final CombatLogPlugin plugin;
    private final CombatManager combatManager;

    private final Set<String> blockedCommands = new HashSet<>();
    private final Set<Material> blockedItems   = new HashSet<>();

    public CombatListener(CombatLogPlugin plugin, CombatManager combatManager) {
        this.plugin = plugin;
        this.combatManager = combatManager;

        for (String cmd : plugin.getConfig().getStringList("blocked-commands"))
            blockedCommands.add(cmd.toLowerCase());

        for (String mat : plugin.getConfig().getStringList("blocked-items")) {
            try { blockedItems.add(Material.valueOf(mat.toUpperCase())); }
            catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Unknown material: " + mat);
            }
        }
    }

    // ── Tag both players on PvP hit ──────────────────────────────────────────

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity()  instanceof Player victim))   return;
        if (!(e.getDamager() instanceof Player attacker)) return;
        combatManager.tag(victim);
        combatManager.tag(attacker);
    }

    // ── Block commands ───────────────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        final Player p = e.getPlayer();
        if (!combatManager.isInCombat(p) || p.hasPermission("combatlog.bypass")) return;
        final String base = e.getMessage().toLowerCase().split(" ")[0].replaceFirst("/", "");
        if (blockedCommands.contains(base)) {
            e.setCancelled(true);
            p.sendMessage(Component.text("✖ /" + base + " is blocked during combat! ", NamedTextColor.RED)
                .append(Component.text("(" + combatManager.getTimeLeft(p.getUniqueId()) + "s remaining)", NamedTextColor.YELLOW)));
        }
    }

    // ── Block item consumption ───────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent e) {
        final Player p = e.getPlayer();
        if (!combatManager.isInCombat(p) || p.hasPermission("combatlog.bypass")) return;
        if (blockedItems.contains(e.getItem().getType())) {
            e.setCancelled(true);
            sendBlocked(p, e.getItem());
        }
    }

    // ── Block item interact (elytra launch, trident throw, pearl throw etc.) ─

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        final Player p = e.getPlayer();
        if (!combatManager.isInCombat(p) || p.hasPermission("combatlog.bypass")) return;
        final ItemStack item = e.getItem();
        if (item == null || item.getType().isAir()) return;
        if (blockedItems.contains(item.getType())) {
            e.setCancelled(true);
            sendBlocked(p, item);
        }
    }

    // ── Block elytra glide activation ────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        final Player p = e.getPlayer();
        if (!combatManager.isInCombat(p) || p.hasPermission("combatlog.bypass")) return;
        // Elytra glide shows as a flight toggle in survival
        if (p.isGliding() || p.getInventory().getChestplate() != null
                && p.getInventory().getChestplate().getType() == Material.ELYTRA) {
            e.setCancelled(true);
            p.sendMessage(Component.text("✖ Elytra is disabled in combat!", NamedTextColor.RED));
        }
    }

    // ── Block elytra glide start ─────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onGlide(PlayerToggleSneakEvent e) {
        // Handled via general item block above; this is a safety net
    }

    // ── Punish disconnect ────────────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onQuit(PlayerQuitEvent e) {
        final Player p = e.getPlayer();
        if (!combatManager.isInCombat(p) || p.hasPermission("combatlog.bypass")) return;
        combatManager.punishCombatLogger(p);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onKick(PlayerKickEvent e) {
        final Player p = e.getPlayer();
        if (!combatManager.isInCombat(p) || p.hasPermission("combatlog.bypass")) return;
        combatManager.punishCombatLogger(p);
    }

    // ── Helper ───────────────────────────────────────────────────────────────

    private void sendBlocked(Player p, ItemStack item) {
        final String raw  = item.getType().name().replace("_", " ").toLowerCase();
        final String name = Character.toUpperCase(raw.charAt(0)) + raw.substring(1);
        p.sendMessage(Component.text("✖ " + name + " cannot be used in combat!", NamedTextColor.RED));
    }
}
