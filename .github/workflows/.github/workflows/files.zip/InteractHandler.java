package com.combatlog.plugin;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class InteractHandler implements Listener {

    private final ItemRegistry reg;

    public InteractHandler(ItemRegistry reg) {
        this.reg = reg;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR
                && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        final Player p = e.getPlayer();
        final ItemStack item = e.getItem();
        if (!reg.isToken(item)) return;

        e.setCancelled(true);

        if (item.getAmount() > 1) item.setAmount(item.getAmount() - 1);
        else p.getInventory().setItemInMainHand(null);

        final ItemStack reward = reg.buildReward();
        if (p.getInventory().firstEmpty() == -1) {
            p.getWorld().dropItemNaturally(p.getLocation(), reward);
        } else {
            p.getInventory().addItem(reward);
        }
    }
}
